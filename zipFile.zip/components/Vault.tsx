
import React, { useState, useMemo, useEffect } from 'react';
import { PasswordEntry, IdentityEntry, AddressSuggestion } from '../types';
import { Plus, Search, Trash2, X, MapPin, Lock, Loader2, Sparkles, RefreshCw, Globe, Shield, Database } from 'lucide-react';
import { encryptData, decryptData } from '../services/cryptoService';
import { suggestAddresses, analyzePasswordStrength, generateNeuralPassphrase } from '../services/geminiService';

const Vault: React.FC<{
  passwords: PasswordEntry[];
  setPasswords: React.Dispatch<React.SetStateAction<PasswordEntry[]>>;
  identities: IdentityEntry[];
  setIdentities: React.Dispatch<React.SetStateAction<IdentityEntry[]>>;
}> = ({ passwords, setPasswords, identities, setIdentities }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [view, setView] = useState<'passwords' | 'identities'>('passwords');
  const [isAdding, setIsAdding] = useState(false);
  
  const [newIdentity, setNewIdentity] = useState<IdentityEntry>({ id: '', label: '', firstName: '', lastName: '', email: '', phone: '', address: '', city: '', state: '', zipCode: '', country: '' });
  const [newEntry, setNewEntry] = useState({ name: '', url: '', username: '', password: '', category: 'Other' as const });
  const [addressSuggestions, setAddressSuggestions] = useState<AddressSuggestion[]>([]);
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [genTheme, setGenTheme] = useState('Cyberpunk');

  const populateMockData = async () => {
    const mockP: PasswordEntry[] = [
      { id: '1', name: 'Google Workspace', url: 'google.com', username: 'dev@guardiapass.io', category: 'Work', lastModified: Date.now(), isEncrypted: true, password: await encryptData('secret123') },
      { id: '2', name: 'GitHub Enclave', url: 'github.com', username: 'neuralshell', category: 'Other', lastModified: Date.now(), isEncrypted: true, password: await encryptData('gh_pat_99') }
    ];
    setPasswords(mockP);
  };

  useEffect(() => {
    if (view === 'identities' && newIdentity.address.length > 5) {
      const timer = setTimeout(async () => {
        setIsSuggesting(true);
        const results = await suggestAddresses(newIdentity.address);
        setAddressSuggestions(results);
        setIsSuggesting(false);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [newIdentity.address, view]);

  const runAnalysis = async (id: string) => {
    setIsAnalyzing(true);
    const entry = passwords.find(p => p.id === id);
    if (entry?.password) {
      const decrypted = await decryptData(entry.password);
      if (decrypted) {
        const analysis = await analyzePasswordStrength(decrypted);
        setPasswords(prev => prev.map(p => p.id === id ? { ...p, securityAnalysis: analysis } : p));
      }
    }
    setIsAnalyzing(false);
  };

  const filteredPasswords = useMemo(() => passwords.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase())), [passwords, searchTerm]);
  const filteredIdentities = useMemo(() => identities.filter(i => i.label.toLowerCase().includes(searchTerm.toLowerCase())), [identities, searchTerm]);

  const handleAiGenerate = async () => {
    setIsGenerating(true);
    const pass = await generateNeuralPassphrase(genTheme);
    setNewEntry(prev => ({ ...prev, password: pass }));
    setIsGenerating(false);
  };

  const saveEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (view === 'passwords') {
      const encrypted = await encryptData(newEntry.password);
      const entry: PasswordEntry = { id: Math.random().toString(36).substr(2, 9), ...newEntry, password: encrypted, lastModified: Date.now(), isEncrypted: true };
      setPasswords([...passwords, entry]);
    } else {
      const entry: IdentityEntry = { ...newIdentity, id: Math.random().toString(36).substr(2, 9) };
      setIdentities([...identities, entry]);
    }
    setIsAdding(false);
  };

  return (
    <div className="p-8 max-w-6xl mx-auto w-full pb-32">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-black text-white uppercase tracking-tighter">Neural <span className="text-emerald-500">Vault</span></h1>
          <p className="text-slate-500 font-medium text-[10px] mt-1 uppercase tracking-[0.3em]">Hardware-Derived Cryptographic Node</p>
        </div>
        <div className="flex gap-4">
          <button onClick={populateMockData} className="px-6 py-4 bg-slate-900 border border-white/5 rounded-2xl text-slate-400 font-black uppercase text-[10px] transition-all flex items-center gap-2 hover:bg-slate-800">
            <Database className="w-4 h-4" /> Seed Debug Data
          </button>
          <button onClick={() => setIsAdding(true)} className="px-8 py-4 bg-emerald-600 hover:bg-emerald-500 rounded-2xl text-white font-black uppercase text-[10px] transition-all flex items-center gap-2 shadow-xl shadow-emerald-500/20">
            <Plus className="w-4 h-4" /> Add Entry
          </button>
        </div>
      </div>

      <div className="flex gap-4 mb-10">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600" />
          <input placeholder="Search vault..." className="w-full bg-black/20 border border-white/5 rounded-2xl py-4 pl-12 pr-6 text-sm outline-none focus:border-indigo-500/30 transition-all" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
        </div>
        <div className="flex bg-black/20 p-1 rounded-2xl border border-white/5">
           {['passwords', 'identities'].map((tab) => (
             <button key={tab} onClick={() => setView(tab as any)} className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${view === tab ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' : 'text-slate-500 hover:text-slate-300'}`}>{tab}</button>
           ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {view === 'passwords' ? (
          filteredPasswords.length > 0 ? filteredPasswords.map(p => (
            <div key={p.id} className="glass-panel p-8 rounded-[2.5rem] bg-black/20 border-white/5 relative group hover:border-indigo-500/20 transition-all">
              <div className="flex items-center justify-between mb-6">
                 <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20 text-indigo-400"><Lock className="w-5 h-5" /></div>
                 <div className="flex gap-2">
                    <button onClick={() => runAnalysis(p.id)} disabled={isAnalyzing} className="p-2 text-slate-600 hover:text-emerald-400 transition-colors"><RefreshCw className={`w-4 h-4 ${isAnalyzing ? 'animate-spin' : ''}`} /></button>
                    <button onClick={() => setPasswords(prev => prev.filter(x => x.id !== p.id))} className="p-2 text-slate-600 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                 </div>
              </div>
              <h3 className="text-lg font-black text-white mb-1 uppercase tracking-tight">{p.name}</h3>
              <p className="text-[10px] text-slate-600 font-mono mb-6 truncate">{p.url}</p>
              <div className="p-4 bg-black/40 rounded-2xl text-[11px] text-slate-300 font-bold border border-white/5">{p.username}</div>
            </div>
          )) : <div className="col-span-3 py-20 text-center opacity-30 text-xs font-black uppercase tracking-widest">Vault is currently empty</div>
        ) : (
          filteredIdentities.length > 0 ? filteredIdentities.map(i => (
            <div key={i.id} className="glass-panel p-8 rounded-[2.5rem] bg-black/20 border-white/5">
               <div className="flex items-center justify-between mb-6">
                  <div className="p-3 bg-emerald-500/10 rounded-2xl border border-emerald-500/20 text-emerald-400"><Globe className="w-5 h-5" /></div>
                  <button onClick={() => setIdentities(prev => prev.filter(x => x.id !== i.id))} className="p-2 text-slate-600 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
               </div>
               <h3 className="text-lg font-black text-white mb-1 uppercase tracking-tight">{i.label}</h3>
               <p className="text-[10px] text-slate-600 font-mono opacity-60">{i.email}</p>
            </div>
          )) : <div className="col-span-3 py-20 text-center opacity-30 text-xs font-black uppercase tracking-widest">No identity nodes stored</div>
        )}
      </div>

      {isAdding && (
        <div className="fixed inset-0 bg-black/95 backdrop-blur-2xl z-[500] flex items-center justify-center p-6">
          <div className="w-full max-w-2xl bg-slate-900 rounded-[3rem] p-12 relative border border-white/10 shadow-2xl">
            <button onClick={() => setIsAdding(false)} className="absolute top-8 right-8 text-slate-500 hover:text-white"><X className="w-6 h-6"/></button>
            <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-10">Deploy New {view === 'passwords' ? 'Neural Secret' : 'Identity Hub'}</h2>
            <form onSubmit={saveEntry} className="space-y-6">
              {view === 'passwords' ? (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <input required placeholder="Label (e.g. Gmail)" className="w-full bg-black/40 border border-white/5 p-4 rounded-2xl text-sm" value={newEntry.name} onChange={e => setNewEntry({...newEntry, name: e.target.value})}/>
                    <input required placeholder="Domain (e.g. google.com)" className="w-full bg-black/40 border border-white/5 p-4 rounded-2xl text-sm" value={newEntry.url} onChange={e => setNewEntry({...newEntry, url: e.target.value})}/>
                  </div>
                  <input required placeholder="Username" className="w-full bg-black/40 border border-white/5 p-4 rounded-2xl text-sm" value={newEntry.username} onChange={e => setNewEntry({...newEntry, username: e.target.value})}/>
                  <div className="flex gap-2">
                    <input required type="password" placeholder="Password" className="flex-1 bg-black/40 border border-white/5 p-4 rounded-2xl text-sm" value={newEntry.password} onChange={e => setNewEntry({...newEntry, password: e.target.value})}/>
                    <button type="button" onClick={handleAiGenerate} disabled={isGenerating} className="p-4 bg-indigo-600 rounded-2xl text-white font-black uppercase text-[10px]">{isGenerating ? '...' : 'AI'}</button>
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <input required placeholder="Profile Label" className="w-full bg-black/40 border border-white/5 p-4 rounded-2xl text-sm" value={newIdentity.label} onChange={e => setNewIdentity({...newIdentity, label: e.target.value})}/>
                  <input required placeholder="Email Address" className="w-full bg-black/40 border border-white/5 p-4 rounded-2xl text-sm" value={newIdentity.email} onChange={e => setNewIdentity({...newIdentity, email: e.target.value})}/>
                  <input placeholder="Physical Address" className="w-full bg-black/40 border border-white/5 p-4 rounded-2xl text-sm" value={newIdentity.address} onChange={e => setNewIdentity({...newIdentity, address: e.target.value})}/>
                </div>
              )}
              <div className="flex gap-4 pt-10">
                <button type="button" onClick={() => setIsAdding(false)} className="flex-1 py-5 text-slate-500 font-black uppercase text-xs">Abort</button>
                <button type="submit" className="flex-2 py-5 bg-indigo-600 hover:bg-indigo-500 rounded-2xl text-white font-black uppercase text-xs">Authorize Store</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Vault;
