
import React, { useState } from 'react';
import { Palette, Shield, Save, RefreshCcw } from 'lucide-react';

export type AppTheme = 'forest' | 'obsidian' | 'neon' | 'arctic';

interface SettingsProps {
  currentTheme: AppTheme;
  setTheme: (theme: AppTheme) => void;
  bgColor: string;
  setBgColor: (color: string) => void;
}

const Settings: React.FC<SettingsProps> = ({ currentTheme, setTheme, bgColor, setBgColor }) => {
  const [isSaved, setIsSaved] = useState(false);

  const themes: { id: AppTheme; name: string; color: string; desc: string }[] = [
    { id: 'forest', name: 'Midnight Forest', color: 'bg-emerald-500', desc: 'Secure environment profile' },
    { id: 'obsidian', name: 'Obsidian Gold', color: 'bg-amber-500', desc: 'Elite vault aesthetic' },
    { id: 'neon', name: 'Cyber Neon', color: 'bg-pink-500', desc: 'High-visibility threat layer' },
    { id: 'arctic', name: 'Arctic Frost', color: 'bg-sky-500', desc: 'Minimalist clinical interface' }
  ];

  const bgColors = [
    { name: 'Deep Void', value: '#020617' },
    { name: 'Emerald Abyss', value: '#061a14' },
    { name: 'Obsidian Glow', value: '#1a1606' },
    { name: 'Arctic Slate', value: '#0f172a' }
  ];

  return (
    <div className="p-8 max-w-6xl mx-auto w-full pb-32 relative">
      {/* Integrity Tag */}
      <div className="absolute top-8 right-8 flex items-center gap-2 px-3 py-1 bg-indigo-500/5 border border-indigo-500/10 rounded-full z-10">
        <Shield className="w-3 h-3 text-indigo-500" />
        <span className="text-[8px] font-black text-indigo-500 uppercase tracking-widest">System Core Root Integrity (Verified)</span>
      </div>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-black text-white tracking-tighter uppercase">System <span className="text-indigo-400">Config</span></h1>
          <p className="text-slate-500 font-medium text-[10px] mt-1 uppercase tracking-[0.3em]">Environment Calibration Panel</p>
        </div>
        <button onClick={() => { setIsSaved(true); setTimeout(() => setIsSaved(false), 2000); }} className="px-8 py-4 bg-indigo-600 rounded-[1.5rem] text-white font-black uppercase tracking-widest text-[10px] shadow-xl shadow-indigo-600/20">
          {isSaved ? 'Environment Updated' : 'Authorize Sync'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="glass-panel p-10 rounded-[3rem] border-white/5 bg-black/20">
          <h3 className="text-xl font-black text-white uppercase tracking-tight flex items-center gap-3 mb-8"><Palette className="w-6 h-6 text-indigo-400" /> Visual Neural Profile</h3>
          <div className="space-y-8">
            <div className="grid grid-cols-2 gap-4">
              {themes.map((t) => (
                <button key={t.id} onClick={() => setTheme(t.id)} className={`p-6 rounded-[2rem] border transition-all text-left ${currentTheme === t.id ? 'border-indigo-500 bg-indigo-500/10' : 'border-white/5 bg-slate-950/40'}`}>
                  <div className={`w-3 h-3 rounded-full mb-4 ${t.color}`} />
                  <h4 className="font-black text-white text-sm uppercase mb-1">{t.name}</h4>
                  <p className="text-[10px] text-slate-500">{t.desc}</p>
                </button>
              ))}
            </div>
            <div>
              <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Background Chroma Tuning</h4>
              <div className="flex flex-wrap gap-3">
                {bgColors.map(c => (
                  <button key={c.value} onClick={() => setBgColor(c.value)} className={`px-4 py-2 rounded-xl border text-[10px] font-black transition-all ${bgColor === c.value ? 'border-indigo-500 bg-indigo-500/10 text-white' : 'border-white/5 text-slate-500'}`}>
                    {c.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="glass-panel p-10 rounded-[3rem] border-white/5 bg-black/20">
          <h3 className="text-xl font-black text-white uppercase tracking-tight flex items-center gap-3 mb-8"><Shield className="w-6 h-6 text-emerald-400" /> Hardware Neural State</h3>
          <div className="p-10 rounded-[2rem] bg-indigo-500/5 border border-indigo-500/20 text-center">
             <RefreshCcw className="w-8 h-8 text-indigo-500 mx-auto mb-4 animate-spin-slow" />
             <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Extension Bridge: Active</p>
             <p className="text-[9px] text-slate-600 font-bold uppercase tracking-tight italic">"Neural core is polling hardware for biometric events..."</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
