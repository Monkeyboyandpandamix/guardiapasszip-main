
# 🛡️ GuardiaPass: AI-Powered Neural Vault

GuardiaPass is a next-generation password management suite featuring real-time URL redirection defense, behavioral analytics, and zero-knowledge encryption.

## ⚡ One-Click Startup (Hackathon Mode)

We have simplified the boot process. You can find pre-configured shortcuts in the **Dashboard > Setup Guide** or create them manually:

### For Windows Users (`start.bat`)
1. Create a file named `start.bat` in the project root.
2. Paste the following (Replace `YOUR_KEY` if not using terminal export):
```batch
@echo off
set API_KEY=YOUR_GEMINI_API_KEY_HERE
npm run dev
```

### For macOS/Linux Users (`start.sh`)
1. Create a file named `start.sh` in the project root.
2. Paste the following:
```bash
#!/bin/bash
export API_KEY="YOUR_GEMINI_API_KEY_HERE"
npm run dev
```
3. Run `chmod +x start.sh` then `./start.sh` to launch.

---

## 🧩 Extension Installation (The Browser Shield)

The extension is required for URL verification and behavioral recording.

1.  **Open Extension Portal**: Navigate to `chrome://extensions` in your browser.
2.  **Enable Developer Mode**: Toggle the switch in the top-right corner.
3.  **Load the Shield**: Click **"Load unpacked"** and select the `extension/` directory.
4.  **Verify Handshake**: Once loaded, go back to the Dashboard. The **"Neural Link"** status will glow emerald.

---

## 🔒 Security Architecture

### Behavioral Recording
The extension monitors navigation events. If a user visits a site with phishing signatures (e.g., `arnazon.com`), the Neural Shield halts the request. Visit frequency is graphed in the **Activity Hub**.

### Zero-Knowledge Vault
*   **Encryption**: AES-GCM-256 (Authenticated Encryption).
*   **Key Derivation**: PBKDF2-SHA256 with 100,000 iterations.
*   **Performance**: Memoized crypto keys for sub-2ms decryption.
