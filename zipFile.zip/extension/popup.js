
const mainScreen = document.getElementById('mainScreen');
const scoutBtn = document.getElementById('scoutBtn');
const list = document.getElementById('list');
const auditIndicator = document.getElementById('auditIndicator');
const auditDomain = document.getElementById('auditDomain');
const itemUrl = document.getElementById('itemUrl');
const itemPhish = document.getElementById('itemPhish');

const tabPasswords = document.getElementById('tabPasswords');
const tabIdentities = document.getElementById('tabIdentities');
const tabEmails = document.getElementById('tabEmails');

let currentTab = 'passwords';
let cachedData = { passwords: [], identities: [], emails: {} };
let verifiedEmails = new Map();

init();

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  runAudit(tab);

  chrome.storage.local.get(['vault', 'foundEmails'], (res) => {
    if (res.vault) {
      cachedData.passwords = res.vault.passwords || [];
      cachedData.identities = res.vault.identities || [];
    }
    if (res.foundEmails) {
      cachedData.emails = res.foundEmails;
    }
    renderList();
  });
}

function runAudit(tab) {
  try {
    const url = new URL(tab.url);
    auditDomain.innerText = url.hostname;
    const isHttps = url.protocol === 'https:';
    itemUrl.className = `audit-item ${isHttps ? 'ok' : 'fail'}`;
    itemUrl.innerText = isHttps ? '✓ Protocol Secured' : '✗ Insecure Protocol';
    
    const brands = ['google', 'paypal', 'facebook', 'amazon', 'microsoft', 'apple', 'netflix'];
    const hostname = url.hostname.toLowerCase();
    const isSuspicious = brands.some(brand => hostname.includes(brand) && !hostname.endsWith(brand + ".com") && !hostname.endsWith(brand + ".org") && !hostname.includes("." + brand + "."));
    
    itemPhish.className = `audit-item ${isSuspicious ? 'fail' : 'ok'}`;
    itemPhish.innerText = isSuspicious ? '✗ High-Confidence Phishing Risk' : '✓ Authentic Domain Profile';
    auditIndicator.className = `audit-indicator ${isSuspicious || !isHttps ? 'indicator-danger' : 'indicator-safe'}`;
  } catch (e) {
    auditIndicator.className = 'audit-indicator indicator-safe';
  }
}

async function verifyEmail(email, el) {
  if (verifiedEmails.has(email)) return;
  
  const scoreBadge = el.querySelector('.risk-score');
  scoreBadge.innerText = 'VERIFYING...';
  scoreBadge.className = 'risk-score risk-med';

  chrome.runtime.sendMessage({ type: 'VERIFY_EMAIL_INTEL', email }, (res) => {
    if (res.status === 'success') {
      const data = res.data;
      verifiedEmails.set(email, data);
      
      const score = data.score;
      const result = data.result;
      
      scoreBadge.innerText = `${score}% | ${result.toUpperCase()}`;
      if (score < 50 || result === 'undeliverable') {
        scoreBadge.className = 'risk-score risk-high';
        el.style.borderLeft = '4px solid #ef4444';
      } else if (score < 80) {
        scoreBadge.className = 'risk-score risk-med';
      } else {
        scoreBadge.className = 'risk-score risk-low';
      }
    } else {
      scoreBadge.innerText = 'FAILED';
      scoreBadge.className = 'risk-score risk-high';
    }
  });
}

async function renderList() {
  list.innerHTML = '';
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const currentDomain = tab ? new URL(tab.url).hostname : '';

  if (currentTab === 'emails') {
    const emails = cachedData.emails[currentDomain] || [];
    if (emails.length === 0) {
      list.innerHTML = '<div style="text-align:center; padding: 40px; color: #475569; font-size: 11px;">No emails discovered on this page node.</div>';
      return;
    }

    emails.forEach(email => {
      const el = document.createElement('div');
      el.className = 'list-item';
      const existing = verifiedEmails.get(email);
      
      el.innerHTML = `
        <div style="min-width: 0; flex:1;">
          <h4 style="font-size:10px; font-family:monospace; color:#10b981;">${email}</h4>
          <p>Email Intelligence Node</p>
        </div>
        <div class="risk-score ${existing ? (existing.score < 50 ? 'risk-high' : 'risk-low') : 'risk-med'}">
          ${existing ? `${existing.score}% | ${existing.result.toUpperCase()}` : 'SCAN EMAIL'}
        </div>
      `;
      
      el.onclick = () => verifyEmail(email, el);
      list.appendChild(el);
    });
    return;
  }

  const data = currentTab === 'passwords' ? cachedData.passwords : cachedData.identities;
  
  if (!data || data.length === 0) {
    list.innerHTML = '<div style="text-align:center; padding: 40px; color: #475569; font-size: 11px;">Vault is empty. Add items in the dashboard.</div>';
    return;
  }

  data.forEach(item => {
    const el = document.createElement('div');
    el.className = 'list-item';
    el.innerHTML = `
      <div style="min-width: 0; flex:1;">
        <h4>${currentTab === 'passwords' ? item.name : item.label}</h4>
        <p>${currentTab === 'passwords' ? item.username : item.email}</p>
      </div>
      <div class="autofill-btn">AUTOFILL</div>
    `;
    el.onclick = async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      chrome.runtime.sendMessage({
        type: 'AUTOFILL_TRIGGER',
        tabId: tab.id,
        mode: currentTab,
        payload: { id: item.id, username: item.username, password: item.password }
      });
      window.close();
    };
    list.appendChild(el);
  });
}

tabPasswords.onclick = () => {
  currentTab = 'passwords';
  tabPasswords.classList.add('active');
  tabIdentities.classList.remove('active');
  tabEmails.classList.remove('active');
  renderList();
};

tabIdentities.onclick = () => {
  currentTab = 'identities';
  tabIdentities.classList.add('active');
  tabPasswords.classList.remove('active');
  tabEmails.classList.remove('active');
  renderList();
};

tabEmails.onclick = () => {
  currentTab = 'emails';
  tabEmails.classList.add('active');
  tabPasswords.classList.remove('active');
  tabIdentities.classList.remove('active');
  renderList();
};

scoutBtn.onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.id) chrome.tabs.sendMessage(tab.id, { type: 'OPEN_PAGE_SCOUT' });
  window.close();
};
