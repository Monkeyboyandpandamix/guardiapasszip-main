
(function() {
  /**
   * GuardiaPass Neural Content Script v13.5
   * Feature: Enhanced Autofill Intelligence & Event Simulation
   */
  
  const isDashboard = document.documentElement.getAttribute('data-guardiapass-role') === 'dashboard' || 
                      document.title.includes("GuardiaPass");

  if (isDashboard) {
    console.debug("[GuardiaPass] Dashboard Bridge Active.");
    
    window.addEventListener('message', (e) => {
      if (e.data && e.data.source === 'guardiapass_dashboard') {
        if (e.data.type === 'VAULT_SYNC') chrome.storage.local.set({ vault: e.data.payload });
        
        if (e.data.type === 'DECRYPTED_AUTOFILL_READY') {
          chrome.runtime.sendMessage({
            type: 'DECRYPTED_DATA_REPLY',
            targetTabId: e.data.targetTabId,
            payload: e.data.payload,
            traceId: e.data.traceId
          });
        }
        
        if (e.data.type === 'AI_AUDIT_RESULT') {
          chrome.runtime.sendMessage({ 
            type: 'AI_RESPONSE_RELAY', 
            text: e.data.text, 
            correlationId: e.data.correlationId,
            traceId: e.data.traceId 
          });
        }
      }
    });

    setInterval(() => {
      window.postMessage({ source: 'guardiapass_extension', type: 'HEARTBEAT' }, "*");
    }, 1000);

    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.source === 'guardiapass_extension') {
        window.postMessage({ ...msg }, "*");
      }
    });
  }

  // --- Email Intelligence Scraper ---
  function scrapeEmails() {
    if (isDashboard) return;
    const bodyText = document.body.innerText;
    const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
    const foundEmails = Array.from(new Set(bodyText.match(emailRegex) || []));
    
    if (foundEmails.length > 0) {
      chrome.storage.local.get(['foundEmails'], (res) => {
        const existing = res.foundEmails || {};
        const url = location.hostname;
        const currentBatch = existing[url] || [];
        const merged = Array.from(new Set([...currentBatch, ...foundEmails])).slice(0, 50);
        existing[url] = merged;
        chrome.storage.local.set({ foundEmails: existing });
      });
    }
  }

  setTimeout(scrapeEmails, 2000);
  setInterval(scrapeEmails, 10000);

  // --- Advanced Injection Engine ---
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'AUTOFILL_EXECUTE_FINAL') {
      const { payload } = msg;
      const allInputs = Array.from(document.querySelectorAll('input'));
      
      // Look for password fields
      let passwordField = allInputs.find(i => 
        i.type === 'password' || 
        i.name?.toLowerCase().includes('pass') || 
        i.id?.toLowerCase().includes('pass') ||
        i.autocomplete?.includes('password')
      );
      
      // Look for user/email fields (Gmail often uses type="email" and name="identifier")
      let userField = allInputs.find(i => 
        (i.type === 'email' || i.type === 'text' || 
         i.name?.toLowerCase().includes('user') || 
         i.name?.toLowerCase().includes('email') || 
         i.name?.toLowerCase().includes('login') ||
         i.id?.toLowerCase().includes('identifier')) && 
        i !== passwordField &&
        i.style.display !== 'none' &&
        i.style.visibility !== 'hidden'
      );

      const simulateInteraction = (el, val) => {
        if (!el || !val) return;
        
        // Force field into active state
        el.focus();
        el.click();
        
        // Set value
        el.value = val;
        
        // Trigger multi-layer events for modern frameworks (React/Vue/Angular)
        const events = ['input', 'change', 'blur'];
        events.forEach(name => {
          const event = new Event(name, { bubbles: true, cancelable: true });
          el.dispatchEvent(event);
        });

        // Visual confirmation
        const originalTransition = el.style.transition;
        const originalShadow = el.style.boxShadow;
        el.style.transition = 'all 0.3s ease';
        el.style.boxShadow = '0 0 15px rgba(16, 185, 129, 0.5)';
        el.style.border = '2px solid #10b981';
        
        setTimeout(() => {
          el.style.boxShadow = originalShadow;
          el.style.transition = originalTransition;
          el.style.border = '';
        }, 1500);
      };

      if (userField) simulateInteraction(userField, payload.username || payload.email);
      if (passwordField) simulateInteraction(passwordField, payload.password);
    }

    if (msg.type === 'OPEN_PAGE_SCOUT') injectScout();
  });

  function injectScout() {
    if (document.getElementById('gp-scout')) return;
    const scout = document.createElement('div');
    scout.id = 'gp-scout';
    scout.innerHTML = `
      <div id="gp-scout-header"><span>NEURAL SCOUT</span><button id="gp-scout-close">×</button></div>
      <div id="gp-scout-chat"></div>
      <div id="gp-scout-input-container"><input type="text" id="gp-scout-input" placeholder="Ask AI about this page..."></div>
    `;
    document.body.appendChild(scout);
    document.getElementById('gp-scout-close').onclick = () => scout.remove();
    
    const input = document.getElementById('gp-scout-input');
    input.onkeypress = (e) => {
      if (e.key === 'Enter' && input.value.trim()) {
        const query = input.value;
        input.value = '';
        const msgDiv = document.createElement('div');
        msgDiv.className = 'gp-msg user';
        msgDiv.innerText = query;
        document.getElementById('gp-scout-chat').appendChild(msgDiv);
        
        chrome.runtime.sendMessage({ 
          type: 'GEMINI_CHAT_REQUEST', 
          payload: { contents: query, page: { url: location.href, title: document.title, text: document.body.innerText.substring(0, 3000) } } 
        }, (res) => {
          const botDiv = document.createElement('div');
          botDiv.className = 'gp-msg bot';
          botDiv.innerText = res.text || "Neural connection error.";
          document.getElementById('gp-scout-chat').appendChild(botDiv);
          document.getElementById('gp-scout-chat').scrollTop = document.getElementById('gp-scout-chat').scrollHeight;
        });
      }
    };
  }
})();
