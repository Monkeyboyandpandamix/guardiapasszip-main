
/**
 * GuardiaPass Background Service Worker v14.0
 * Feature: Enhanced Autofill Routing & Hunter.io Integration
 */

let visitCache = [];
const pendingRequests = new Map();
const HUNTER_API_KEY = '920fb161b322f859e4e4af33a38e5f90483b35e4';

async function findDashboardTab() {
  const tabs = await chrome.tabs.query({});
  return tabs.find(t => 
    (t.url && (t.url.includes("localhost") || t.url.includes("127.0.0.1") || t.url.includes("guardiapass"))) || 
    (t.title && t.title.includes("GuardiaPass"))
  );
}

// Flush telemetry with batch deduplication
setInterval(async () => {
  if (visitCache.length === 0) return;
  const dash = await findDashboardTab();
  if (dash) {
    chrome.tabs.sendMessage(dash.id, { 
      source: 'guardiapass_extension', 
      type: 'VISIT_BATCH', 
      payload: visitCache,
      traceId: Math.random().toString(36).substr(2, 5)
    }).catch(() => {});
    visitCache = [];
  }
}, 2000);

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const traceId = Math.random().toString(36).substr(2, 5);

  if (request.type === 'AUTOFILL_TRIGGER') {
    findDashboardTab().then(dash => {
      if (dash) {
        chrome.tabs.sendMessage(dash.id, { 
          source: 'guardiapass_extension', 
          type: 'REQUEST_DECRYPT_FOR_AUTOFILL', 
          payload: request.payload,
          targetTabId: request.tabId, // This is critical for Gmail/Sequential logins
          traceId
        });
        sendResponse({ status: 'relayed', traceId });
      } else {
        sendResponse({ status: 'error', msg: 'Dashboard closed' });
      }
    });
    return true;
  }

  if (request.type === 'VERIFY_EMAIL_INTEL') {
    const url = `https://api.hunter.io/v2/email-verifier?email=${encodeURIComponent(request.email)}&api_key=${HUNTER_API_KEY}`;
    fetch(url)
      .then(res => res.json())
      .then(data => sendResponse({ status: 'success', data: data.data }))
      .catch(err => sendResponse({ status: 'error', msg: err.message }));
    return true;
  }

  if (request.type === 'DECRYPTED_DATA_REPLY') {
    // Relay the decrypted payload to the actual website tab
    if (request.targetTabId) {
      chrome.tabs.sendMessage(request.targetTabId, {
        type: 'AUTOFILL_EXECUTE_FINAL',
        payload: request.payload,
        traceId: request.traceId
      });
    }
    return false;
  }

  if (request.type === 'GEMINI_CHAT_REQUEST') {
    const correlationId = request.correlationId || Math.random().toString(36).substr(2, 5);
    pendingRequests.set(correlationId, sendResponse);
    
    findDashboardTab().then(dash => {
      if (dash) {
        chrome.tabs.sendMessage(dash.id, { ...request, correlationId, traceId, source: 'guardiapass_extension' });
      } else {
        const responder = pendingRequests.get(correlationId);
        if (responder) {
           responder({ text: "The GuardiaPass Dashboard is not open. Please open it to use AI features." });
           pendingRequests.delete(correlationId);
        }
      }
    });
    return true;
  }

  if (request.type === 'AI_RESPONSE_RELAY') {
    const responder = pendingRequests.get(request.correlationId);
    if (responder) {
      responder({ text: request.text });
      pendingRequests.delete(request.correlationId);
    }
    return false;
  }
});
