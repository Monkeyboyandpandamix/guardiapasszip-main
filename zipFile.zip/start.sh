#!/bin/bash
echo "[SHIELD] Activating Neural Bridge..."
echo "[SHIELD] Synchronizing Neural Core Dependencies..."
npm install
echo "[SHIELD] Establishing Secure Session..."
export API_KEY="AIzaSyBe1c1gTckDdApAEKD4pmcbFql_JaHq7Pg"
npm run dev