
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { AppSection, PasswordEntry, IdentityEntry, VisitRecord, SessionState } from './types';
import Sidebar from './components/Sidebar';
import Vault from './components/Vault';
import Verifier from './components/Verifier';
import Analytics from './components/Analytics';
import DownloadPage from './components/Download';
import Settings, { AppTheme } from './components/Settings';
import AuthGateway from './components/AuthGateway';
import NetworkMonitor from './components/NetworkMonitor';
import ExtensionSimulator from './components/ExtensionSimulator';
import { Lock, Terminal, X, Activity } from 'lucide-react';
import { askPageQuestion } from './services/geminiService';
import { decryptData } from './services/cryptoService';

const App: React.FC = () => {
  const [session, setSession] = useState<SessionState>({ isLocked: true, userEmail: null, lastActive: Date.now() });
  const [activeSection, setActiveSection] = useState<AppSection>(AppSection.Vault);
  const [theme, setTheme] = useState<AppTheme>(() => (localStorage.getItem('gp_theme') as AppTheme) || 'forest');
  const [bgColor, setBgColor] = useState(() => localStorage.getItem('gp_bg_color') || '#020617');
  
  const [passwords, setPasswords] = useState<PasswordEntry[]>([]);
  const [identities, setIdentities] = useState<IdentityEntry[]>([]);
  const [visits, setVisits] = useState<VisitRecord[]>([]);
  const [isExtensionActive, setIsExtensionActive] = useState(false);
  const [debugLogs, setDebugLogs] = useState<{time: string, msg: string, type: 'in' | 'out' | 'sys', traceId?: string}[]>([]);
  const [showDebug, setShowDebug] = useState(false);
  const [chatHistories, setChatHistories] = useState<Record<string, { role: 'user' | 'model', text: string }[]>>({});
  const [isLoaded, setIsLoaded] = useState(false);
  
  const lastHeartbeat = useRef<number>(Date.now());

  const addLog = useCallback((msg: string, type: 'in' | 'out' | 'sys' = 'sys', traceId?: string) => {
    setDebugLogs(prev => [{ 
      time: new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }), 
      msg, type, traceId
    }, ...prev].slice(0, 50));
  }, []);

  useEffect(() => {
    const p = localStorage.getItem('guardiapass_passwords');
    const i = localStorage.getItem('guardiapass_identities');
    const v = localStorage.getItem('guardiapass_visits');
    if (p) setPasswords(JSON.parse(p));
    if (i) setIdentities(JSON.parse(i));
    if (v) setVisits(JSON.parse(v));
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    if (!isLoaded) return;
    localStorage.setItem('guardiapass_passwords', JSON.stringify(passwords));
    localStorage.setItem('guardiapass_identities', JSON.stringify(identities));
    localStorage.setItem('guardiapass_visits', JSON.stringify(visits));
  }, [passwords, identities, visits, isLoaded]);

  useEffect(() => {
    document.body.style.backgroundColor = bgColor;
  }, [bgColor]);

  const syncToExtension = useCallback(() => {
    window.postMessage({ source: 'guardiapass_dashboard', type: 'VAULT_SYNC', payload: { passwords, identities } }, "*");
  }, [passwords, identities]);

  const handleBridgeMessages = useCallback(async (event: MessageEvent) => {
    const data = event.data;
    if (data?.source !== 'guardiapass_extension') return;

    const { type, payload, correlationId, targetTabId, traceId } = data;

    if (type === 'HEARTBEAT') {
      lastHeartbeat.current = Date.now();
      if (!isExtensionActive) {
        setIsExtensionActive(true);
        addLog("Bridge: Signal Established", "sys");
      }
      syncToExtension();
      return;
    }

    if (type === 'VISIT_BATCH') {
      const batch = Array.isArray(payload) ? payload : [payload];
      setVisits(prev => {
        const updated = [...batch, ...prev].slice(0, 500);
        return updated;
      });
      addLog(`Telemetry: Received ${batch.length} packets`, 'in', traceId);
    }

    if (type === 'GEMINI_CHAT_REQUEST') {
      addLog(`Scout: Processing Query`, 'in', traceId);
      const { contents, page } = payload;
      const history = chatHistories[page.url] || [];
      try {
        const response = await askPageQuestion(page, contents, history);
        setChatHistories(prev => ({
          ...prev,
          [page.url]: [...history, { role: 'user', text: contents }, { role: 'model', text: response }]
        }));

        window.postMessage({ 
          source: 'guardiapass_dashboard', 
          type: 'AI_AUDIT_RESULT', 
          text: response, 
          correlationId, 
          traceId 
        }, "*");
        addLog(`Scout: Response Dispatched`, 'out', traceId);
      } catch (err) {
        addLog(`Scout: Analysis Failed`, 'sys', traceId);
      }
    }

    if (type === 'REQUEST_DECRYPT_FOR_AUTOFILL') {
      addLog(`Autofill: Decrypting node for Tab ${targetTabId}`, 'in', traceId);
      const dec = await decryptData(payload.password);
      window.postMessage({ 
        source: 'guardiapass_dashboard', 
        type: 'DECRYPTED_AUTOFILL_READY', 
        targetTabId, 
        payload: { ...payload, password: dec }, 
        traceId 
      }, "*");
      addLog(`Autofill: Decrypted payload released to bridge`, 'out', traceId);
    }
  }, [isExtensionActive, addLog, syncToExtension, chatHistories]);

  useEffect(() => {
    window.addEventListener('message', handleBridgeMessages);
    const watchdog = setInterval(() => {
      if (Date.now() - lastHeartbeat.current > 10000 && isExtensionActive) {
        setIsExtensionActive(false);
        addLog("Bridge: Signal Lost", "sys");
      }
    }, 5000);
    return () => {
      window.removeEventListener('message', handleBridgeMessages);
      clearInterval(watchdog);
    };
  }, [handleBridgeMessages, isExtensionActive, addLog]);

  const handleUnlock = (email: string) => {
    setSession({ isLocked: false, userEmail: email, lastActive: Date.now() });
    addLog(`Identity Confirmed: ${email}`, 'sys');
  };

  if (session.isLocked) return <AuthGateway onUnlock={handleUnlock} />;

  const activeColor = theme === 'forest' ? 'emerald' : theme === 'obsidian' ? 'amber' : theme === 'neon' ? 'pink' : 'sky';

  return (
    <div className={`flex flex-col lg:flex-row h-screen overflow-hidden text-slate-200 theme-${theme}`} style={{ backgroundColor: bgColor }}>
      <Sidebar activeSection={activeSection} setActiveSection={setActiveSection} isSecure={isExtensionActive} activeColor={activeColor} />
      <main className="flex-1 flex flex-col min-w-0 h-full relative">
        <header className="h-16 shrink-0 border-b border-white/5 flex items-center justify-between px-8 bg-black/20 backdrop-blur-xl z-30">
          <div className="flex items-center gap-3">
             <div className={`w-2 h-2 rounded-full ${isExtensionActive ? `bg-${activeColor}-500 shadow-[0_0_10px_#10b981]` : 'bg-slate-700'}`} />
             <span className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500">
               {isExtensionActive ? 'Uplink Synchronized' : 'Searching for Signal...'}
             </span>
          </div>
          <div className="flex items-center gap-4">
             <button onClick={() => setShowDebug(!showDebug)} className={`p-2.5 transition-all relative ${showDebug ? 'text-indigo-400' : 'text-slate-500 hover:text-indigo-400'}`}>
               <Terminal className="w-4 h-4" />
               {isExtensionActive && !showDebug && <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-indigo-500 rounded-full animate-ping" />}
             </button>
             <button onClick={() => setSession(s => ({...s, isLocked: true}))} className="p-2.5 text-slate-500 hover:text-red-400 transition-all">
               <Lock className="w-4 h-4" />
             </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {activeSection === AppSection.Vault && <Vault passwords={passwords} setPasswords={setPasswords} identities={identities} setIdentities={setIdentities} />}
          {activeSection === AppSection.Verifier && <Verifier onVisit={(url) => { window.open(url, '_blank'); }} />}
          {activeSection === AppSection.Network && <NetworkMonitor isSecure={isExtensionActive} visits={visits} />}
          {activeSection === AppSection.Analytics && <Analytics visits={visits} />}
          {activeSection === AppSection.Download && <DownloadPage />}
          {activeSection === AppSection.Settings && <Settings currentTheme={theme} setTheme={setTheme} bgColor={bgColor} setBgColor={setBgColor} />}
        </div>

        {activeSection === AppSection.Verifier && (
          <div className="fixed bottom-0 right-0 w-1/2 h-1/2 z-[50] pointer-events-none opacity-20 hover:opacity-100 transition-opacity">
            <div className="w-full h-full pointer-events-auto">
               <ExtensionSimulator onNavigate={() => {}} />
            </div>
          </div>
        )}

        {showDebug && (
          <div className="absolute right-0 top-16 bottom-0 w-96 bg-[#020617]/98 backdrop-blur-3xl border-l border-white/10 z-[100] flex flex-col font-mono animate-in slide-in-from-right duration-500 shadow-2xl">
            <div className="p-6 border-b border-white/10 flex items-center justify-between bg-black/40">
              <span className="text-xs font-black uppercase text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-500"/> Bridge Telemetry
              </span>
              <button onClick={() => setShowDebug(false)}><X className="w-4 h-4 text-slate-500 hover:text-white"/></button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3 text-[10px]">
              {debugLogs.map((log, i) => (
                <div key={i} className={`p-3 rounded-xl border border-white/5 animate-in fade-in slide-in-from-top-1 ${log.type === 'in' ? 'text-indigo-400 bg-indigo-500/5' : log.type === 'out' ? 'text-emerald-400 bg-emerald-500/5' : 'text-amber-500 bg-amber-500/5'}`}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="opacity-40 text-[8px] font-bold">{log.type.toUpperCase()}</span>
                    <span className="opacity-40 text-[8px] font-bold">{log.time}</span>
                  </div>
                  <div className="font-bold leading-relaxed mb-1">{log.msg}</div>
                  {log.traceId && <div className="text-[7px] text-slate-600 font-mono tracking-tighter">TRACE_ID: {log.traceId}</div>}
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
